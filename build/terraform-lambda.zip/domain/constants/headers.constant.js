"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.responseHeaders = void 0;
exports.responseHeaders = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
};
//# sourceMappingURL=headers.constant.js.map