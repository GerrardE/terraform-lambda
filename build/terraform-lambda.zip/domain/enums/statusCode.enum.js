"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.statusCode = void 0;
var statusCode;
(function (statusCode) {
    statusCode[statusCode["ok"] = 200] = "ok";
    statusCode[statusCode["badrequest"] = 400] = "badrequest";
    statusCode[statusCode["notaccepted"] = 406] = "notaccepted";
    statusCode[statusCode["error"] = 500] = "error";
})(statusCode = exports.statusCode || (exports.statusCode = {}));
//# sourceMappingURL=statusCode.enum.js.map