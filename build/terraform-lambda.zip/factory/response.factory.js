"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createResponse = void 0;
const headers_constant_1 = require("../domain/constants/headers.constant");
const createResponse = ({ code = 200, headers = headers_constant_1.responseHeaders, body = {}, }) => {
    return {
        statusCode: code,
        headers: headers,
        body: JSON.stringify(body),
    };
};
exports.createResponse = createResponse;
//# sourceMappingURL=response.factory.js.map