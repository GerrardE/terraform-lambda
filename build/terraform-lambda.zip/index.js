"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEvent = exports.createEvent = void 0;
var index_1 = require("./logic/index");
Object.defineProperty(exports, "createEvent", { enumerable: true, get: function () { return index_1.createEvent; } });
Object.defineProperty(exports, "getEvent", { enumerable: true, get: function () { return index_1.getEvent; } });
//# sourceMappingURL=index.js.map