"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEvent = exports.createEvent = void 0;
const statusCode_enum_1 = require("../domain/enums/statusCode.enum");
const response_factory_1 = require("../factory/response.factory");
const createEvent = async (event = {}) => {
    return (0, response_factory_1.createResponse)({
        code: statusCode_enum_1.statusCode.ok,
        headers: event.headers,
        body: {
            response: "Welcome to terraform-lambda API, here are the details of your request:",
            headers: event.headers,
            method: event.httpMethod,
            body: event.body,
        },
    });
};
exports.createEvent = createEvent;
const getEvent = async (event = {}) => {
    return (0, response_factory_1.createResponse)({
        code: statusCode_enum_1.statusCode.ok,
        body: {
            response: "Welcome to terraform-lambda API, here are the details of your request:",
            headers: event.headers,
            method: event.httpMethod,
            body: event.body,
        },
    });
};
exports.getEvent = getEvent;
//# sourceMappingURL=index.js.map